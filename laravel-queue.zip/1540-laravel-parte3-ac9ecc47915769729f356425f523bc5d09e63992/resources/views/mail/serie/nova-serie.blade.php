@component('mail::message')

#Nova Série
### Nome da Série: {{$nome}}
### Qtd Temporadas: {{$qtdTemporadas}}
### Qtd Episódios: {{$qtdEpisodios}}

@endcomponent
